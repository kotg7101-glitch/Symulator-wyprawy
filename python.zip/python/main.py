import turtle
import random
import math

print("=== SYMULATOR WYPRAWY ===")

name = input("Podaj nazwę łazika: ")

x = int(input("Start X: "))
y = int(input("Start Y: "))

angle = int(input("Kąt startowy (0-359): "))

energy = int(input("Początkowa energia: "))

steps = 0
max_steps = 20

world_limit = 100

goal_x = random.randint(-80, 80)
goal_y = random.randint(-80, 80)

history = []

# OKNO
screen = turtle.Screen()
screen.title("Wyprawa Łazika")

# ŁAZIK
pen = turtle.Turtle()
pen.speed(1)

pen.penup()
pen.goto(x, y)
pen.pendown()

# GRANICE ŚWIATA
border = turtle.Turtle()
border.hideturtle()
border.speed(0)

border.penup()
border.goto(-100, -100)
border.pendown()

for i in range(4):
    border.forward(200)
    border.left(90)

# CEL
goal = turtle.Turtle()
goal.hideturtle()

goal.penup()
goal.goto(goal_x, goal_y)
goal.dot(15, "red")

print("\nCel misji:", goal_x, goal_y)

game = True

while game:

    steps += 1

    print("\n-------------------")
    print("Krok:", steps)
    print("Pozycja:", x, y)
    print("Energia:", energy)
    print("Kąt:", angle)
    print("-------------------")

    print("\n1 - Skręć w lewo")
    print("2 - Skręć w prawo")
    print("3 - Jedź prosto")

    choice = input("Wybierz ruch: ")

    if choice == "1":
        angle += 45

    elif choice == "2":
        angle -= 45

    angle = angle % 360

    distance = random.randint(5, 15)

    rad = math.radians(angle)

    move_x = int(math.cos(rad) * distance)
    move_y = int(math.sin(rad) * distance)

    x += move_x
    y += move_y

    energy -= 10

    pen.goto(x, y)

    history.append(
        "Krok " + str(steps) +
        ": pozycja=(" +
        str(x) + "," +
        str(y) +
        ") energia=" +
        str(energy)
    )

    # ZDARZENIA LOSOWE

    if random.randint(1, 100) <= 20:
        energy -= 15
        print("Burza piaskowa! -15 energii")

    if random.randint(1, 100) <= 15:
        energy += 20
        print("Znaleziono baterię! +20 energii")

    # WARUNKI KOŃCA

    if energy <= 0:
        print("\nKONIEC: Brak energii")
        game = False

    elif steps >= max_steps:
        print("\nKONIEC: Limit kroków")
        game = False

    elif abs(x) > world_limit or abs(y) > world_limit:
        print("\nKONIEC: Łazik opuścił świat")
        game = False

    elif abs(x - goal_x) < 10 and abs(y - goal_y) < 10:
        print("\nSUKCES: Dotarto do celu!")
        game = False

print("\n===== RAPORT KOŃCOWY =====")

print("Nazwa łazika:", name)
print("Końcowa pozycja:", x, y)
print("Liczba kroków:", steps)
print("Pozostała energia:", energy)

print("\nHistoria wyprawy:")

for item in history:
    print(item)

turtle.done()