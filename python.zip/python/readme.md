# Symulator wyprawy po dwuwymiarowym świecie

Program symuluje wyprawę łazika w świecie 2D.

## Funkcje programu
- ruch po współrzędnych x i y,
- energia łazika,
- zdarzenia losowe,
- granice świata,
- raport końcowy,
- wizualizacja w turtle.

## Uruchomienie
1. Uruchom plik main.py
2. Wpisz dane startowe
3. Steruj łazikiem w terminalu

Program działa w Python 3.11.